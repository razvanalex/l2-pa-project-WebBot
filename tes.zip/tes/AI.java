import hlt.*;

import java.util.*;

class Pair<F, S> {
	private F first;
	private S second;

	public Pair(F first, S second) {
		this.first = first;
		this.second = second;
	}

	public F getFirst() {
		return this.first;
	}

	public S getSecond() {
		return this.second;
	}

	@Override
	public String toString() {
		return "(" + this.first + " "  + this.second + ")";
	}
}

public class AI {

	public static TreeMap<Double, List<Pair<Ship, Planet>>> sort(GameMap gameMap, List<Ship> ourShips, List<Planet> noOnePlanets) {
		TreeMap<Double, List<Pair<Ship, Planet>>> result = new TreeMap<>();

//        ArrayList<Planet> planets = new ArrayList<>();
		for (Planet p : noOnePlanets) {
			for (Ship s : ourShips) {

				double distance = s.getRealDistanceTo(gameMap, p);
				List<Pair<Ship, Planet>> l = result.get(distance);
				if (l == null) {
					l = new ArrayList<>();
				}
				l.add(new Pair<>(s, p));
				Collections.sort(l, new Comparator<Pair<Ship, Planet>>() {
					@Override
					public int compare(Pair<Ship, Planet> o1, Pair<Ship, Planet> o2) {
						return o1.getFirst().getId() - o2.getFirst().getId();
					}
				});
				result.put(distance, l);
			}
		}
		Log.log("Result..." + result);
		return result;
	}

	public static Pair<Integer, Planet> initialStrat(GameMap gameMap, List<Ship> attackShips, List<Planet> noOnePlanets) {
		TreeMap<Double, List<Pair<Ship, Planet>>> tree = sort(gameMap, attackShips, noOnePlanets);
		if (tree.isEmpty())
			return null;

		double min = Double.MAX_VALUE;
		Planet bestPlanet = null;

		double score;
		for (Map.Entry<Double, List<Pair<Ship, Planet>>> list = tree.pollFirstEntry(); !tree.isEmpty(); list = tree.pollFirstEntry()) {
			for (Pair<Ship, Planet> pair : list.getValue()) {
				Planet p = pair.getSecond();
				if (p.getNumShipsTowardsPlanet() > (p.getDockingSpots() - p.getDockedShips().size())) {
					continue;
				}

				score = (double) p.getDockingSpots() / list.getKey();
				if (min > score || bestPlanet == null) {
					min = score;
					bestPlanet = p;
				}

			}
		}


		return new Pair<Integer, Planet>((int) min, bestPlanet);
	}

}
