import hlt.*;
import java.util.*;

//TODO de dat un score[i] : (num_ships) ^ 3 * d[i] distanta de la nava la spre aceiasi planeta i nava
//TODO raport attack_def = our_ship / (our_ship + enemy_ship )* C, de gasit cine este C
//TODO solve initial start


public class MyBot {
	public static int turn = 1;
	private static TreeMap<Integer, Planet> cache = new TreeMap<Integer, Planet>();

	/**
	 * Compute the overall score of the board. It is computed as the sum of
	 * the percentage of our ships and the percentage of our planets times
	 * the difference between number of ships. A low value means a low chance
	 * of winning, so we have to defend ourselves; and a high value means that
	 * there is a chance of winning the game, so attack.
	 * <p>
	 * The highest value is 100% + 100% * numOfShips = numOfShips + 1
	 * The lowest score is 0% + 0% * (0 - numEnemyPlanets) = 0
	 * <p>
	 * Hence, a medium score should be somewhere between numOfShips + 1 and 0.
	 * Note that there is a chance of having a negative value.
	 * So, to maximize the chance of winning, the limit between attack and
	 * deffend will be chosen as 2 / 3 * (numOfShips + 1)
	 * <p>
	 * TODO: This hypothesis has to be verified.
	 */

	public static double overallScore(int numOurShips, int numEnemyShips,
	                                  int numOurPlanets, int numEnemyPlanets) {

		double shipScore = (double) numOurShips / (numOurShips + numEnemyShips);
		double planetScore = numOurPlanets + numEnemyPlanets > 0 ?
				(double) numOurPlanets / (numOurPlanets + numEnemyPlanets) : 0;

		// Compute effectiveness
		double effectiveness = shipScore + planetScore * (numOurShips - numEnemyShips);

		return effectiveness;
	}

	public static ArrayList<Move> __(GameMap gameMap, int numOurShips, int numEnemyShips,
									 int numOurPlanets, int numEnemyPlanets) {

		ArrayList<Move> moves = new ArrayList<>();
		int random = 0;
		for (Ship s : gameMap.getMyPlayer().getShips().values()) {
			if (s.getDockingStatus() != Ship.DockingStatus.Undocked) {
				continue;
			}

			Map<Double, Entity> entities = gameMap.nearbyEntitiesByDistance(s);
			TreeMap<Double, Planet> emptyPlanets = new TreeMap<Double, Planet>();
			List<Ship> enemy = new ArrayList<>();


			for (Map.Entry<Double, Entity> e : entities.entrySet()) {
				if (e.getValue() instanceof Planet && !(((Planet) e.getValue()).isFull())) {
					//emptyPlanets.add((Planet)e.getValue());
					Planet planet = (Planet) e.getValue();
					double score = s.getDistanceTo(planet);
					emptyPlanets.put(score, planet);
				} else if (e.getValue() instanceof Ship
						&& ((Ship) e.getValue()).getOwner() != gameMap.getMyPlayerId()) {
					enemy.add((Ship) e.getValue());
				}
			}

			double effectiveness = overallScore(numOurShips, numEnemyShips, numOurPlanets, numEnemyPlanets);

			if (!emptyPlanets.isEmpty() && numEnemyShips >= numOurShips) {
				Planet target = emptyPlanets.pollFirstEntry().getValue();
				if (cache.containsKey(s.getId())) {
					if (s.canDock(cache.get(s.getId()))) {
						moves.add(new DockMove(s, (Planet) cache.get(s.getId())));
						cache.remove(s.getId());
						Log.log(cache.containsKey(s.getId()) + " Has target");
					} else {
						final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap,
								s, cache.get(s.getId()), Constants.MAX_SPEED, true);

						if (newThrustMove != null) {
							Log.log(cache.containsKey(s.getId()) + " From cache");
							moves.add(newThrustMove);
						}

					}
				} else {
					if (s.canDock(target) && random % 2 == 0) {
						moves.add(new DockMove(s, target));
						Log.log(cache.containsKey(s.getId()) + " No target");
					} else {
						final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap,
								s, target, Constants.MAX_SPEED, true);

						if (newThrustMove != null) {
							Log.log(s.getId() + " New target " + target.getId());
							cache.put(((Ship) s).getId(), target);
							moves.add(newThrustMove);
						}
					}
				}
			} else if (!enemy.isEmpty()) {
				Ship target = enemy.get(0);
				Log.log("attack");
				final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap,
						s, target, Constants.MAX_SPEED, true);

				if (newThrustMove != null) {
					moves.add(newThrustMove);
				}
			}

			random++;
		}
		return moves;
	}

	public static void main(final String[] args) {
		final Networking networking = new Networking();
		final GameMap gameMap = networking.initialize("WebBot");

		// We now have 1 full minute to analyse the initial map.
		final String initialMapIntelligence =
				"width: " + gameMap.getWidth() +
						"; height: " + gameMap.getHeight() +
						"; players: " + gameMap.getAllPlayers().size() +
						"; planets: " + gameMap.getAllPlanets().size();
		Log.log(initialMapIntelligence);

		ArrayList<Move> moveList = new ArrayList<>();
		//incepe jocul
		for (; ; turn++) {
			moveList.clear();
			networking.updateMap(gameMap);

			//o tura
			List<Ship> ships = new LinkedList<Ship>();
			for (Ship ship : gameMap.getMyPlayer().getShips().values())
				if (ship.getDockingStatus() == Ship.DockingStatus.Undocked)
					ships.add(ship);

			List<Planet> planets = new LinkedList<Planet>();
			List<Planet> ourPlanets = new LinkedList<Planet>();
			List<Planet> enemyPlanets = new LinkedList<Planet>();

			for (Planet planet : gameMap.getAllPlanets().values()) {
				/** Divide all planets in 3 sets: not owned, ours and enemies' */
				if (!planet.isOwned()) {
					planets.add(planet);
				} else if (planet.getOwner() == gameMap.getMyPlayerId()) {
					ourPlanets.add(planet);
				} else {
					enemyPlanets.add(planet);
				}
			}

			// giveOrdersCaptain(gameMap, moveList, planets, ourPlanets, enemyPlanets, ships);
			moveList = __(gameMap, ships.size(), gameMap.getAllShips().size() - ships.size(),
				ourPlanets.size(), enemyPlanets.size());

			Networking.sendMoves(moveList);
		}
	}


}
